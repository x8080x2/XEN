const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs').promises;
const { existsSync } = require('fs');
const https = require('https');
const http = require('http');
const os = require('os');
const crypto = require('crypto');

// Load environment variables
require('dotenv').config();

// Keep a global reference of the window object
let mainWindow;

// Generate hardware fingerprint based on IP address
function generateHardwareFingerprint() {
  try {
    const networkInterfaces = os.networkInterfaces();
    
    // Find the first non-internal IPv4 address
    for (const interfaceName in networkInterfaces) {
      const interfaces = networkInterfaces[interfaceName];
      for (const iface of interfaces) {
        // Skip internal (loopback) and non-IPv4 addresses
        if (!iface.internal && iface.family === 'IPv4') {
          console.log('[Electron] Using IP address for hardware fingerprint:', iface.address);
          return crypto.createHash('sha256').update(iface.address).digest('hex');
        }
      }
    }
    
    // Fallback if no external IP found (shouldn't happen in normal cases)
    console.warn('[Electron] No external IP found, using hostname fallback');
    const fallbackId = os.hostname();
    return crypto.createHash('sha256').update(fallbackId).digest('hex');
  } catch (error) {
    console.error('[Electron] Error generating hardware fingerprint:', error);
    // Emergency fallback
    const emergencyId = os.hostname();
    return crypto.createHash('sha256').update(emergencyId).digest('hex');
  }
}

// License verification function
async function verifyLicense() {
  try {
    const licenseKey = process.env.LICENSE_KEY;

    if (!licenseKey) {
      return {
        valid: false,
        error: 'No license key found in .env file'
      };
    }

    // Get server URL from environment
    const serverUrl = process.env.REPLIT_SERVER_URL;
    if (!serverUrl) {
      return {
        valid: false,
        error: 'REPLIT_SERVER_URL not configured in .env file'
      };
    }

    // Generate hardware fingerprint
    const hardwareId = generateHardwareFingerprint();
    console.log('[Electron] Hardware ID:', hardwareId.substring(0, 16) + '...');
    console.log('[Electron] Verifying license with server...');

    // Verify license with server
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);

    try {
      const response = await fetch(`${serverUrl}/api/license/verify`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          licenseKey,
          hardwareId 
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        return {
          valid: false,
          error: `Server returned status ${response.status}`
        };
      }

      const result = await response.json();

      if (result.valid) {
        console.log('[Electron] ✅ License verified successfully');
        return {
          valid: true,
          licenseKey,
          license: result.license
        };
      } else {
        return {
          valid: false,
          error: result.reason || 'License verification failed'
        };
      }
    } catch (fetchError) {
      clearTimeout(timeoutId);
      if (fetchError.name === 'AbortError') {
        return {
          valid: false,
          error: 'License verification timed out (10s)'
        };
      }
      throw fetchError;
    }
  } catch (error) {
    console.error('[Electron] License verification error:', error);
    return {
      valid: false,
      error: `License verification failed: ${error.message}`
    };
  }
}

function createWindow() {
  // Create the browser window
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    icon: path.join(__dirname, 'assets/icon.png'), // Optional: add app icon
    title: 'Email Sender - Desktop App'
  });

  // Load the React app
  const isDev = process.env.NODE_ENV === 'development';

  if (isDev) {
    // In development, load from Vite dev server
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools();
  } else {
    // In production, load from built files with hash routing
    const indexPath = path.join(__dirname, 'dist/index.html');
    mainWindow.loadURL(`file://${indexPath}#/`);
  }

  // Pass server URL to renderer process
  mainWindow.webContents.on('did-finish-load', () => {
    const serverUrl = process.env.REPLIT_SERVER_URL;
    if (serverUrl) {
      mainWindow.webContents.executeJavaScript(`
        window.REPLIT_SERVER_URL = '${serverUrl}';
        console.log('[Electron] Server URL set to:', '${serverUrl}');
      `);
    } else {
      console.log('[Electron] No REPLIT_SERVER_URL environment variable set');
    }

  });

  // Emitted when the window is closed
  mainWindow.on('closed', function () {
    mainWindow = null;
  });
}

// This method will be called when Electron has finished initialization
app.whenReady().then(async () => {
  console.log('[Electron] Starting Email Sender Desktop App...');

  const licenseResult = await verifyLicense();

  if (!licenseResult.valid) {
    console.error('[Electron] ❌ License verification failed:', licenseResult.error);

    const { dialog } = require('electron');
    
    // Check for specific error message about already activated
    let errorTitle = 'License Verification Failed';
    let errorMessage = 'Invalid or Missing License';
    let errorDetail = licenseResult.error;
    
    if (licenseResult.error && licenseResult.error.includes('already activated on another computer')) {
      errorTitle = 'License Already Activated';
      errorMessage = 'This license is already in use on another computer';
      errorDetail = 'Each license can only be activated on one computer at a time.\n\nIf you need to transfer this license, please contact support.';
    }
    
    await dialog.showMessageBox({
      type: 'error',
      title: errorTitle,
      message: errorMessage,
      detail: errorDetail,
      buttons: ['Exit']
    });

    app.quit();
    return;
  }

  console.log('[Electron] ✅ License verified - Starting application...');
  createWindow();
});

// Quit when all windows are closed
app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', function () {
  if (mainWindow === null) createWindow();
});

// IPC handlers for file operations
ipcMain.handle('read-file', async (event, filepath) => {
  try {
    console.log(`[Electron] Reading file: ${filepath}`);

    // Use only the user-package directory as base
    const resolvedPath = path.resolve(__dirname, filepath);
    console.log(`[Electron] Resolved path: ${resolvedPath}`);

    if (existsSync(resolvedPath)) {
      const content = await fs.readFile(resolvedPath, 'utf-8');
      console.log(`[Electron] Successfully read file: ${filepath} (${content.length} chars)`);
      return content;
    }

    throw new Error(`File not found: ${filepath}`);
  } catch (error) {
    console.error(`[Electron] Failed to read file ${filepath}:`, error);
    throw error;
  }
});

ipcMain.handle('write-file', async (event, filepath, content) => {
  try {
    console.log(`[Electron] Writing file: ${filepath}`);

    // Resolve relative paths from the app directory
    const resolvedPath = path.resolve(process.cwd(), filepath);

    // Ensure directory exists
    const dir = path.dirname(resolvedPath);
    await fs.mkdir(dir, { recursive: true });

    await fs.writeFile(resolvedPath, content, 'utf-8');
    console.log(`[Electron] Successfully wrote file: ${filepath}`);
    return true;
  } catch (error) {
    console.error(`[Electron] Failed to write file ${filepath}:`, error);
    return false;
  }
});

ipcMain.handle('list-files', async (event, dirpath) => {
  try {
    console.log(`[Electron] Listing files in: ${dirpath}`);

    // Use only the user-package directory as base
    const resolvedPath = path.resolve(__dirname, dirpath);
    console.log(`[Electron] Resolved directory: ${resolvedPath}`);

    if (!existsSync(resolvedPath)) {
      console.log(`[Electron] Directory not found: ${dirpath}`);
      return [];
    }

    const files = await fs.readdir(resolvedPath);

    // Filter files based on directory type
    let filteredFiles;
    if (dirpath.includes('logo')) {
      // For logo directory, filter image files
      filteredFiles = files.filter(file => /\.(png|jpg|jpeg|gif|webp|svg)$/i.test(file));
      console.log(`[Electron] Found ${filteredFiles.length} image files in ${dirpath}:`, filteredFiles);
    } else {
      // For other directories, filter HTML files
      filteredFiles = files.filter(file => /\.(html|htm)$/i.test(file));
      console.log(`[Electron] Found ${filteredFiles.length} HTML files in ${dirpath}:`, filteredFiles);
    }

    return filteredFiles;
  } catch (error) {
    console.error(`[Electron] Failed to list files in ${dirpath}:`, error);
    return [];
  }
});

ipcMain.handle('read-config', async (event, configDir) => {
  try {
    console.log(`[Electron] Reading config from: ${configDir}`);

    // Try multiple base directories
    const basePaths = [
      __dirname, // user-package directory
      process.cwd(), // current working directory
      path.resolve(__dirname, '..'), // parent directory
    ];

    const config = {};

    for (const basePath of basePaths) {
      const setupPath = path.resolve(basePath, configDir, 'setup.ini');
      const smtpPath = path.resolve(basePath, configDir, 'smtp.ini');

      console.log(`[Electron] Checking config paths in: ${basePath}`);

      // Read setup.ini if it exists
      if (existsSync(setupPath)) {
        const setupContent = await fs.readFile(setupPath, 'utf-8');
        console.log(`[Electron] Found setup.ini at ${setupPath}`);
        config.setup = setupContent;
      }

      // Read smtp.ini if it exists
      if (existsSync(smtpPath)) {
        const smtpContent = await fs.readFile(smtpPath, 'utf-8');
        console.log(`[Electron] Found smtp.ini at ${smtpPath}`);
        config.smtp = smtpContent;
      }

      // If we found any config files, break out of the loop
      if (config.setup || config.smtp) {
        console.log(`[Electron] Found config files in: ${basePath}`);
        break;
      }
    }

    return config;
  } catch (error) {
    console.error(`[Electron] Failed to read config from ${configDir}:`, error);
    return {};
  }
});

ipcMain.handle('select-file', async () => {
  try {
    const result = await dialog.showOpenDialog(mainWindow, {
      properties: ['openFile'],
      filters: [
        { name: 'HTML Files', extensions: ['html', 'htm'] },
        { name: 'Text Files', extensions: ['txt'] },
        { name: 'All Files', extensions: ['*'] }
      ]
    });

    if (!result.canceled && result.filePaths.length > 0) {
      return result.filePaths[0];
    }
    return null;
  } catch (error) {
    console.error('[Electron] Failed to select file:', error);
    return null;
  }
});

ipcMain.handle('select-files', async () => {
  try {
    const result = await dialog.showOpenDialog(mainWindow, {
      properties: ['openFile', 'multiSelections'],
      filters: [
        { name: 'All Files', extensions: ['*'] }
      ]
    });

    if (!result.canceled && result.filePaths.length > 0) {
      return result.filePaths;
    }
    return null;
  } catch (error) {
    console.error('[Electron] Failed to select files:', error);
    return null;
  }
});

// Config loading with fallback support
ipcMain.handle('load-config', async () => {
  try {
    console.log(`[Electron] Loading config files`);

    // Try multiple base directories
    const basePaths = [
      __dirname, // user-package directory
      process.cwd(), // current working directory
      path.resolve(__dirname, '..'), // parent directory
    ];

    const config = {};
    let setupContent = '';
    let smtpContent = '';

    for (const basePath of basePaths) {
      const setupPath = path.resolve(basePath, 'config', 'setup.ini');
      const smtpPath = path.resolve(basePath, 'config', 'smtp.ini');

      console.log(`[Electron] Checking config paths in: ${basePath}`);

      // Read setup.ini if it exists
      if (existsSync(setupPath)) {
        setupContent = await fs.readFile(setupPath, 'utf-8');
        console.log(`[Electron] Found setup.ini at ${setupPath}`);
        const setupConfig = parseIniFile(setupContent);
        Object.assign(config, setupConfig.CONFIG || {});
        Object.assign(config, setupConfig.PROXY || {});
      }

      // Read smtp.ini if it exists
      if (existsSync(smtpPath)) {
        const smtpContent = await fs.readFile(smtpPath, 'utf-8');
        console.log(`[Electron] Found smtp.ini at ${smtpPath}`);
        const smtpConfig = parseIniFile(smtpContent);

        // Get first SMTP config as current
        const smtpKeys = Object.keys(smtpConfig).filter(key => key.startsWith('smtp'));
        if (smtpKeys.length > 0) {
          const firstSmtp = smtpConfig[smtpKeys[0]];
          config.SMTP = firstSmtp;
          console.log(`[Electron] Loaded SMTP config:`, firstSmtp);
        }
      }

      // If we found config files, break out of the loop
      if (setupContent || smtpContent) {
        console.log(`[Electron] Found config files in: ${basePath}`);
        break;
      }
    }

    return { success: true, config };
  } catch (error) {
    console.error(`[Electron] Failed to load config:`, error);
    return { success: false, config: {} };
  }
});

// Load leads file
ipcMain.handle('load-leads', async () => {
  try {
    console.log(`[Electron] Loading leads file`);

    // Try multiple locations for leads.txt
    const possiblePaths = [
      path.resolve(__dirname, 'files', 'leads.txt'), // user-package directory
      path.resolve(process.cwd(), 'files', 'leads.txt'), // current working directory
      path.resolve(__dirname, '..', 'files', 'leads.txt'), // parent directory
    ];

    for (const testPath of possiblePaths) {
      console.log(`[Electron] Trying leads path: ${testPath}`);
      if (existsSync(testPath)) {
        const content = await fs.readFile(testPath, 'utf-8');
        console.log(`[Electron] Successfully loaded leads from ${testPath} (${content.length} chars)`);
        return { success: true, leads: content };
      }
    }

    console.log(`[Electron] Leads file not found in any location`);
    return { success: false, leads: '' };
  } catch (error) {
    console.error(`[Electron] Failed to load leads:`, error);
    return { success: false, leads: '' };
  }
});

// SMTP rotation state storage
let smtpRotationEnabled = false;
let currentSmtpIndex = 0;

// SMTP toggle rotation handler
ipcMain.handle('smtp-toggle-rotation', async (event, enabled) => {
  try {
    console.log(`[Electron] Toggling SMTP rotation to: ${enabled}`);
    smtpRotationEnabled = enabled;

    const basePaths = [
      __dirname,
      process.cwd(),
      path.resolve(__dirname, '..')
    ];

    let smtpPath = null;
    let statePath = null;

    // Find config files
    for (const basePath of basePaths) {
      const testSmtpPath = path.resolve(basePath, 'config', 'smtp.ini');
      const testStatePath = path.resolve(basePath, 'config', 'smtp-rotation.json');
      
      if (existsSync(testSmtpPath)) {
        smtpPath = testSmtpPath;
        statePath = testStatePath;
        break;
      }
    }

    // Load current SMTP configs to return current SMTP
    let currentSmtp = null;
    if (smtpPath && existsSync(smtpPath)) {
      const smtpContent = await fs.readFile(smtpPath, 'utf-8');
      const smtpConfigs = parseSmtpIni(smtpContent);
      
      if (smtpConfigs.length > 0) {
        // Use current index to get current SMTP
        const validIndex = currentSmtpIndex < smtpConfigs.length ? currentSmtpIndex : 0;
        currentSmtp = smtpConfigs[validIndex];
      }
    }

    await fs.mkdir(path.dirname(statePath), { recursive: true });
    await fs.writeFile(statePath, JSON.stringify({ 
      rotationEnabled: enabled,
      currentIndex: currentSmtpIndex 
    }), 'utf-8');

    console.log(`[Electron] SMTP rotation state saved: ${enabled}, index: ${currentSmtpIndex}`);
    return { 
      success: true, 
      rotationEnabled: enabled,
      currentSmtp: currentSmtp
    };
  } catch (error) {
    console.error(`[Electron] Failed to save rotation state:`, error);
    return { success: false, rotationEnabled: smtpRotationEnabled };
  }
});

// SMTP rotate handler
ipcMain.handle('smtp-rotate', async () => {
  try {
    console.log(`[Electron] Rotating SMTP server`);

    const basePaths = [
      __dirname,
      process.cwd(),
      path.resolve(__dirname, '..')
    ];

    let smtpPath = null;
    let statePath = null;

    // Find SMTP config file
    for (const basePath of basePaths) {
      const testSmtpPath = path.resolve(basePath, 'config', 'smtp.ini');
      const testStatePath = path.resolve(basePath, 'config', 'smtp-rotation.json');
      
      if (existsSync(testSmtpPath)) {
        smtpPath = testSmtpPath;
        statePath = testStatePath;
        break;
      }
    }

    if (!smtpPath) {
      return { success: false, error: 'SMTP config file not found' };
    }

    // Load SMTP configs
    const smtpContent = await fs.readFile(smtpPath, 'utf-8');
    const smtpConfigs = parseSmtpIni(smtpContent);

    if (smtpConfigs.length <= 1) {
      return { success: false, error: 'Need at least 2 SMTP configs to rotate' };
    }

    // Load current index from state file
    let savedIndex = 0;
    if (existsSync(statePath)) {
      try {
        const stateContent = await fs.readFile(statePath, 'utf-8');
        const state = JSON.parse(stateContent);
        savedIndex = state.currentIndex || 0;
        smtpRotationEnabled = state.rotationEnabled || false;
      } catch (error) {
        console.error(`[Electron] Failed to parse rotation state:`, error);
      }
    }

    // Calculate next index
    currentSmtpIndex = (savedIndex + 1) % smtpConfigs.length;
    const nextSmtp = smtpConfigs[currentSmtpIndex];

    // Save updated state
    await fs.mkdir(path.dirname(statePath), { recursive: true });
    await fs.writeFile(statePath, JSON.stringify({ 
      rotationEnabled: smtpRotationEnabled,
      currentIndex: currentSmtpIndex 
    }), 'utf-8');

    console.log(`[Electron] Rotated to SMTP index ${currentSmtpIndex}: ${nextSmtp.fromEmail}`);

    return {
      success: true,
      currentSmtp: nextSmtp,
      rotationEnabled: smtpRotationEnabled
    };
  } catch (error) {
    console.error(`[Electron] Failed to rotate SMTP:`, error);
    return { success: false, error: error.message };
  }
});

// SMTP list handler
ipcMain.handle('smtp-list', async () => {
  try {
    console.log(`[Electron] Loading SMTP configurations`);

    const basePaths = [
      __dirname, // user-package directory
      process.cwd(), // current working directory
      path.resolve(__dirname, '..'), // parent directory
    ];

    let rotationEnabled = false;
    let savedIndex = 0;

    for (const basePath of basePaths) {
      const smtpPath = path.resolve(basePath, 'config', 'smtp.ini');
      const statePath = path.resolve(basePath, 'config', 'smtp-rotation.json');

      console.log(`[Electron] Checking SMTP path: ${smtpPath}`);

      if (existsSync(statePath)) {
        try {
          const stateContent = await fs.readFile(statePath, 'utf-8');
          const state = JSON.parse(stateContent);
          rotationEnabled = state.rotationEnabled || false;
          savedIndex = state.currentIndex || 0;
          smtpRotationEnabled = rotationEnabled;
          currentSmtpIndex = savedIndex;
          console.log(`[Electron] Loaded rotation state: enabled=${rotationEnabled}, index=${savedIndex}`);
        } catch (error) {
          console.error(`[Electron] Failed to parse rotation state:`, error);
        }
      }

      if (existsSync(smtpPath)) {
        console.log(`[Electron] Found SMTP config at: ${smtpPath}`);
        const smtpContent = await fs.readFile(smtpPath, 'utf-8');
        const smtpConfigs = parseSmtpIni(smtpContent);

        // Use saved index to determine current SMTP, fallback to first if index is out of range
        const validIndex = savedIndex < smtpConfigs.length ? savedIndex : 0;
        const currentSmtp = smtpConfigs[validIndex] || null;

        return {
          success: true,
          smtpConfigs,
          currentSmtp: currentSmtp,
          rotationEnabled: rotationEnabled
        };
      }
    }

    console.log(`[Electron] No SMTP config found`);
    return { success: true, smtpConfigs: [], currentSmtp: null, rotationEnabled: rotationEnabled };
  } catch (error) {
    console.error(`[Electron] Failed to load SMTP configs:`, error);
    return { success: false, smtpConfigs: [], currentSmtp: null, rotationEnabled: false };
  }
});

// Parse INI file format
function parseIniFile(content) {
  const result = {};
  let currentSection = '';

  const lines = content.split('\n');
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith(';') || trimmed.startsWith('#')) {
      continue;
    }

    // Section header
    if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
      currentSection = trimmed.slice(1, -1);
      result[currentSection] = {};
      continue;
    }

    // Key-value pair
    const equalIndex = trimmed.indexOf('=');
    if (equalIndex > 0) {
      const key = trimmed.substring(0, equalIndex).trim();
      const value = trimmed.substring(equalIndex + 1).trim();

      if (currentSection) {
        result[currentSection][key] = parseValue(value);
      } else {
        result[key] = parseValue(value);
      }
    }
  }

  return result;
}

// SMTP add handler
ipcMain.handle('smtp-add', async (event, smtpData) => {
  try {
    console.log(`[Electron] Adding new SMTP config:`, smtpData);
    
    if (!smtpData.host || !smtpData.port || !smtpData.user || !smtpData.pass || !smtpData.fromEmail) {
      return { success: false, error: 'All SMTP fields are required' };
    }

    const basePaths = [
      __dirname,
      process.cwd(),
      path.resolve(__dirname, '..')
    ];

    let smtpPath = null;
    let existingContent = '';

    // Find existing smtp.ini or create in first basePath
    for (const basePath of basePaths) {
      const testPath = path.resolve(basePath, 'config', 'smtp.ini');
      if (existsSync(testPath)) {
        smtpPath = testPath;
        existingContent = await fs.readFile(smtpPath, 'utf-8');
        break;
      }
    }

    // If no existing file, create in first basePath
    if (!smtpPath) {
      smtpPath = path.resolve(basePaths[0], 'config', 'smtp.ini');
      await fs.mkdir(path.dirname(smtpPath), { recursive: true });
    }

    // Parse existing configs to find next available index
    const existingConfigs = existingContent ? parseSmtpIni(existingContent) : [];
    const existingIds = existingConfigs.map(s => s.id);
    let nextIndex = 0;
    while (existingIds.includes(`smtp${nextIndex}`)) {
      nextIndex++;
    }

    const smtpId = `smtp${nextIndex}`;
    const newSection = `\n[${smtpId}]\nhost=${smtpData.host}\nport=${smtpData.port}\nuser=${smtpData.user}\npass=${smtpData.pass}\nfromEmail=${smtpData.fromEmail}\nfromName=${smtpData.fromName || ''}\n`;

    await fs.writeFile(smtpPath, existingContent + newSection, 'utf-8');
    console.log(`[Electron] SMTP config ${smtpId} added successfully`);

    // Reload and return updated list
    const updatedContent = await fs.readFile(smtpPath, 'utf-8');
    const smtpConfigs = parseSmtpIni(updatedContent);

    return {
      success: true,
      smtpId: smtpId,
      smtpConfigs: smtpConfigs,
      currentSmtp: smtpConfigs[0] || null
    };
  } catch (error) {
    console.error(`[Electron] Failed to add SMTP config:`, error);
    return { success: false, error: error.message };
  }
});

// SMTP delete handler
ipcMain.handle('smtp-delete', async (event, smtpId) => {
  try {
    console.log(`[Electron] Deleting SMTP config: ${smtpId}`);

    const basePaths = [
      __dirname,
      process.cwd(),
      path.resolve(__dirname, '..')
    ];

    let smtpPath = null;
    let existingContent = '';

    // Find existing smtp.ini
    for (const basePath of basePaths) {
      const testPath = path.resolve(basePath, 'config', 'smtp.ini');
      if (existsSync(testPath)) {
        smtpPath = testPath;
        existingContent = await fs.readFile(smtpPath, 'utf-8');
        break;
      }
    }

    if (!smtpPath) {
      return { success: false, error: 'SMTP config file not found' };
    }

    // Parse and remove the specified section
    const lines = existingContent.split('\n');
    const newLines = [];
    let inTargetSection = false;
    let sectionFound = false;

    for (const line of lines) {
      const trimmed = line.trim();
      
      // Check if this is the section we want to delete
      if (trimmed === `[${smtpId}]`) {
        inTargetSection = true;
        sectionFound = true;
        continue;
      }
      
      // Check if we're entering a new section
      if (trimmed.startsWith('[') && trimmed.endsWith(']')) {
        inTargetSection = false;
      }
      
      // Only add lines that are not in the target section
      if (!inTargetSection) {
        newLines.push(line);
      }
    }

    if (!sectionFound) {
      return { success: false, error: 'SMTP config not found' };
    }

    // Write updated content
    await fs.writeFile(smtpPath, newLines.join('\n'), 'utf-8');
    console.log(`[Electron] SMTP config ${smtpId} deleted successfully`);

    // Reload and return updated list
    const updatedContent = await fs.readFile(smtpPath, 'utf-8');
    const smtpConfigs = parseSmtpIni(updatedContent);

    return {
      success: true,
      smtpConfigs: smtpConfigs,
      currentSmtp: smtpConfigs[0] || null
    };
  } catch (error) {
    console.error(`[Electron] Failed to delete SMTP config:`, error);
    return { success: false, error: error.message };
  }
});

// File upload handler
ipcMain.handle('file-upload', async (event, sourceFilePath) => {
  try {
    console.log(`[Electron] Uploading file: ${sourceFilePath}`);

    if (!existsSync(sourceFilePath)) {
      return { success: false, error: 'Source file not found' };
    }

    const crypto = require('crypto');
    const originalName = path.basename(sourceFilePath);
    const ext = path.extname(originalName);
    const filename = `${crypto.randomUUID()}${ext}`;
    const uploadsDir = path.resolve(__dirname, 'uploads');
    const destPath = path.resolve(uploadsDir, filename);

    await fs.mkdir(uploadsDir, { recursive: true });
    await fs.copyFile(sourceFilePath, destPath);

    const stats = await fs.stat(destPath);
    
    const mimeTypes = {
      '.pdf': 'application/pdf',
      '.png': 'image/png',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.gif': 'image/gif',
      '.html': 'text/html',
      '.txt': 'text/plain'
    };

    console.log(`[Electron] File uploaded successfully: ${filename}`);

    return {
      success: true,
      id: crypto.randomUUID(),
      originalName: originalName,
      filename: filename,
      path: `uploads/${filename}`,
      size: stats.size,
      mimeType: mimeTypes[ext.toLowerCase()] || 'application/octet-stream',
      uploadedAt: new Date()
    };
  } catch (error) {
    console.error(`[Electron] Failed to upload file:`, error);
    return { success: false, error: error.message };
  }
});

// Parse SMTP INI file format and convert to array
function parseSmtpIni(content) {
  const parsed = parseIniFile(content);
  const smtpConfigs = [];

  // Convert INI sections to array format
  for (const key in parsed) {
    if (key.startsWith('smtp')) {
      const smtpConfig = {
        id: key,
        host: parsed[key].host || '',
        port: parsed[key].port || '587',
        user: parsed[key].user || '',
        pass: parsed[key].pass || '',
        fromEmail: parsed[key].fromEmail || '',
        fromName: parsed[key].fromName || ''
      };
      smtpConfigs.push(smtpConfig);
      console.log(`[Electron] Parsed SMTP config ${key}:`, smtpConfig);
    }
  }

  console.log(`[Electron] Total SMTP configs parsed: ${smtpConfigs.length}`);
  return smtpConfigs;
}


// Parse config values
function parseValue(value) {
  if (value === '') return '';
  if (value === '0') return 0;
  if (value === '1') return 1;
  if (/^\d+$/.test(value)) return parseInt(value, 10);
  if (/^\d+\.\d+$/.test(value)) return parseFloat(value);
  return value;
}

// Security: Prevent new window creation
app.on('web-contents-created', (event, contents) => {
  contents.on('new-window', (event, navigationUrl) => {
    event.preventDefault();
  });
});