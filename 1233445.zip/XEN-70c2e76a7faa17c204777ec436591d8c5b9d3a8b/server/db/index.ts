
// This file is now consolidated into server/db.ts
// Re-export the main database instance
export { db, pool } from "../db";
